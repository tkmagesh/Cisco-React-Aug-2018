export function add(x,y){
	return x + y;
}

export function subtract(x,y){
	return x - y;
}

let calculator = { add, subtract };

export default calculator;